export default {
    'siteInfo': { 'title': "Random User Generator" },
    'pages': [
        {
            'name': 'home',
            'onMenu': true,
            'title': 'Home Sweet Home',
            'content': 'dskjfhakfh sadkfhksdafhasl adkjfhakfhakdf alkdjhskfjhafkaj akljdsfhjkasdfhjkashf afkhdskahf akdhfkjasfh'
        },
        {
            'name': 'away',
            'onMenu': true,
            'title': 'Gone Away',
            'content': 'dskjfhakfh <a href="http://www.google.ca">sadkfhksdafhasl</a> adkjfhakfhakdf alkdjhskfjhafkaj akljdsfhjkasdfhjkashf afkhdskahf akdhfkjasfh'
        },
        {
            'name': 'here',
            'onMenu': false,
            'title': 'Here',
            'content': 'dskjfhakfh <a href="http://www.google.ca">sadkfhksdafhasl</a> adkjfhakfhakdf alkdjhskfjhafkaj akljdsfhjkasdfhjkashf afkhdskahf akdhfkjasfh'
        },
    ]
};